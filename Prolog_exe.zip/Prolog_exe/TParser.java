// $ANTLR 3.5.2 T.g 2021-05-07 18:26:07

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

@SuppressWarnings("all")
public class TParser extends Parser {
	public static final String[] tokenNames = new String[] {
		"<invalid>", "<EOR>", "<DOWN>", "<UP>", "Digit", "ID", "Op", "String", 
		"UC", "WS", "'('", "').'", "','", "'?-'"
	};
	public static final int EOF=-1;
	public static final int T__10=10;
	public static final int T__11=11;
	public static final int T__12=12;
	public static final int T__13=13;
	public static final int Digit=4;
	public static final int ID=5;
	public static final int Op=6;
	public static final int String=7;
	public static final int UC=8;
	public static final int WS=9;

	// delegates
	public Parser[] getDelegates() {
		return new Parser[] {};
	}

	// delegators


	public TParser(TokenStream input) {
		this(input, new RecognizerSharedState());
	}
	public TParser(TokenStream input, RecognizerSharedState state) {
		super(input, state);
	}

	@Override public String[] getTokenNames() { return TParser.tokenNames; }
	@Override public String getGrammarFileName() { return "T.g"; }


		Tsem s = new Tsem();



	// $ANTLR start "prog"
	// T.g:14:1: prog : identifierList ;
	public final void prog() throws RecognitionException {
		try {
			// T.g:14:6: ( identifierList )
			// T.g:14:8: identifierList
			{
			pushFollow(FOLLOW_identifierList_in_prog37);
			identifierList();
			state._fsp--;
			if (state.failed) return;
			}

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "prog"



	// $ANTLR start "identifierList"
	// T.g:17:1: identifierList : ( identifier identifierList |);
	public final void identifierList() throws RecognitionException {
		try {
			// T.g:17:16: ( identifier identifierList |)
			int alt1=2;
			int LA1_0 = input.LA(1);
			if ( (LA1_0==ID||LA1_0==13) ) {
				alt1=1;
			}
			else if ( (LA1_0==EOF) ) {
				alt1=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return;}
				NoViableAltException nvae =
					new NoViableAltException("", 1, 0, input);
				throw nvae;
			}

			switch (alt1) {
				case 1 :
					// T.g:17:18: identifier identifierList
					{
					pushFollow(FOLLOW_identifier_in_identifierList47);
					identifier();
					state._fsp--;
					if (state.failed) return;
					pushFollow(FOLLOW_identifierList_in_identifierList49);
					identifierList();
					state._fsp--;
					if (state.failed) return;
					}
					break;
				case 2 :
					// T.g:18:44: 
					{
					}
					break;

			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "identifierList"



	// $ANTLR start "identifier"
	// T.g:21:1: identifier : ( fact | query );
	public final void identifier() throws RecognitionException {
		try {
			// T.g:21:11: ( fact | query )
			int alt2=2;
			int LA2_0 = input.LA(1);
			if ( (LA2_0==ID) ) {
				alt2=1;
			}
			else if ( (LA2_0==13) ) {
				alt2=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return;}
				NoViableAltException nvae =
					new NoViableAltException("", 2, 0, input);
				throw nvae;
			}

			switch (alt2) {
				case 1 :
					// T.g:21:13: fact
					{
					pushFollow(FOLLOW_fact_in_identifier61);
					fact();
					state._fsp--;
					if (state.failed) return;
					}
					break;
				case 2 :
					// T.g:21:20: query
					{
					pushFollow(FOLLOW_query_in_identifier65);
					query();
					state._fsp--;
					if (state.failed) return;
					}
					break;

			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "identifier"



	// $ANTLR start "fact"
	// T.g:24:1: fact : id1= ID '(' id2= ID ',' id3= ID ').' ;
	public final void fact() throws RecognitionException {
		Token id1=null;
		Token id2=null;
		Token id3=null;

		try {
			// T.g:24:5: (id1= ID '(' id2= ID ',' id3= ID ').' )
			// T.g:24:9: id1= ID '(' id2= ID ',' id3= ID ').'
			{
			id1=(Token)match(input,ID,FOLLOW_ID_in_fact79); if (state.failed) return;
			match(input,10,FOLLOW_10_in_fact81); if (state.failed) return;
			id2=(Token)match(input,ID,FOLLOW_ID_in_fact87); if (state.failed) return;
			match(input,12,FOLLOW_12_in_fact89); if (state.failed) return;
			id3=(Token)match(input,ID,FOLLOW_ID_in_fact94); if (state.failed) return;
			if ( state.backtracking==0 ) {s.input((id1!=null?id1.getText():null),(id2!=null?id2.getText():null),(id3!=null?id3.getText():null));}
			match(input,11,FOLLOW_11_in_fact104); if (state.failed) return;
			}

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "fact"



	// $ANTLR start "query"
	// T.g:29:1: query : '?-' id1= ID '(' id2= ID ',' id3= ID ').' ;
	public final void query() throws RecognitionException {
		Token id1=null;
		Token id2=null;
		Token id3=null;

		try {
			// T.g:29:6: ( '?-' id1= ID '(' id2= ID ',' id3= ID ').' )
			// T.g:29:8: '?-' id1= ID '(' id2= ID ',' id3= ID ').'
			{
			match(input,13,FOLLOW_13_in_query113); if (state.failed) return;
			id1=(Token)match(input,ID,FOLLOW_ID_in_query119); if (state.failed) return;
			match(input,10,FOLLOW_10_in_query121); if (state.failed) return;
			id2=(Token)match(input,ID,FOLLOW_ID_in_query127); if (state.failed) return;
			match(input,12,FOLLOW_12_in_query129); if (state.failed) return;
			id3=(Token)match(input,ID,FOLLOW_ID_in_query135); if (state.failed) return;
			match(input,11,FOLLOW_11_in_query137); if (state.failed) return;
			if ( state.backtracking==0 ) {s.query((id1!=null?id1.getText():null),(id2!=null?id2.getText():null),(id3!=null?id3.getText():null));}
			}

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "query"

	// Delegated rules



	public static final BitSet FOLLOW_identifierList_in_prog37 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_identifier_in_identifierList47 = new BitSet(new long[]{0x0000000000002020L});
	public static final BitSet FOLLOW_identifierList_in_identifierList49 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_fact_in_identifier61 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_query_in_identifier65 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_ID_in_fact79 = new BitSet(new long[]{0x0000000000000400L});
	public static final BitSet FOLLOW_10_in_fact81 = new BitSet(new long[]{0x0000000000000020L});
	public static final BitSet FOLLOW_ID_in_fact87 = new BitSet(new long[]{0x0000000000001000L});
	public static final BitSet FOLLOW_12_in_fact89 = new BitSet(new long[]{0x0000000000000020L});
	public static final BitSet FOLLOW_ID_in_fact94 = new BitSet(new long[]{0x0000000000000800L});
	public static final BitSet FOLLOW_11_in_fact104 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_13_in_query113 = new BitSet(new long[]{0x0000000000000020L});
	public static final BitSet FOLLOW_ID_in_query119 = new BitSet(new long[]{0x0000000000000400L});
	public static final BitSet FOLLOW_10_in_query121 = new BitSet(new long[]{0x0000000000000020L});
	public static final BitSet FOLLOW_ID_in_query127 = new BitSet(new long[]{0x0000000000001000L});
	public static final BitSet FOLLOW_12_in_query129 = new BitSet(new long[]{0x0000000000000020L});
	public static final BitSet FOLLOW_ID_in_query135 = new BitSet(new long[]{0x0000000000000800L});
	public static final BitSet FOLLOW_11_in_query137 = new BitSet(new long[]{0x0000000000000002L});
}
