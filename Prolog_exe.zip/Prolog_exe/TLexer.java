// $ANTLR 3.5.2 T.g 2021-05-07 18:26:07

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class TLexer extends Lexer {
	public static final int EOF=-1;
	public static final int T__10=10;
	public static final int T__11=11;
	public static final int T__12=12;
	public static final int T__13=13;
	public static final int Digit=4;
	public static final int ID=5;
	public static final int Op=6;
	public static final int String=7;
	public static final int UC=8;
	public static final int WS=9;

	// delegates
	// delegators
	public Lexer[] getDelegates() {
		return new Lexer[] {};
	}

	public TLexer() {} 
	public TLexer(CharStream input) {
		this(input, new RecognizerSharedState());
	}
	public TLexer(CharStream input, RecognizerSharedState state) {
		super(input,state);
	}
	@Override public String getGrammarFileName() { return "T.g"; }

	// $ANTLR start "T__10"
	public final void mT__10() throws RecognitionException {
		try {
			int _type = T__10;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:7:7: ( '(' )
			// T.g:7:9: '('
			{
			match('('); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "T__10"

	// $ANTLR start "T__11"
	public final void mT__11() throws RecognitionException {
		try {
			int _type = T__11;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:8:7: ( ').' )
			// T.g:8:9: ').'
			{
			match(")."); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "T__11"

	// $ANTLR start "T__12"
	public final void mT__12() throws RecognitionException {
		try {
			int _type = T__12;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:9:7: ( ',' )
			// T.g:9:9: ','
			{
			match(','); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "T__12"

	// $ANTLR start "T__13"
	public final void mT__13() throws RecognitionException {
		try {
			int _type = T__13;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:10:7: ( '?-' )
			// T.g:10:9: '?-'
			{
			match("?-"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "T__13"

	// $ANTLR start "Digit"
	public final void mDigit() throws RecognitionException {
		try {
			int _type = Digit;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:33:6: ( ( '-' )? ( '0' .. '9' )+ )
			// T.g:33:8: ( '-' )? ( '0' .. '9' )+
			{
			// T.g:33:8: ( '-' )?
			int alt1=2;
			int LA1_0 = input.LA(1);
			if ( (LA1_0=='-') ) {
				alt1=1;
			}
			switch (alt1) {
				case 1 :
					// T.g:33:9: '-'
					{
					match('-'); 
					}
					break;

			}

			// T.g:33:14: ( '0' .. '9' )+
			int cnt2=0;
			loop2:
			while (true) {
				int alt2=2;
				int LA2_0 = input.LA(1);
				if ( ((LA2_0 >= '0' && LA2_0 <= '9')) ) {
					alt2=1;
				}

				switch (alt2) {
				case 1 :
					// T.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					if ( cnt2 >= 1 ) break loop2;
					EarlyExitException eee = new EarlyExitException(2, input);
					throw eee;
				}
				cnt2++;
			}

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "Digit"

	// $ANTLR start "ID"
	public final void mID() throws RecognitionException {
		try {
			int _type = ID;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:37:3: ( ( 'a' .. 'z' | '\\_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '\\_' )* )
			// T.g:37:5: ( 'a' .. 'z' | '\\_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '\\_' )*
			{
			if ( input.LA(1)=='_'||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
				input.consume();
			}
			else {
				MismatchedSetException mse = new MismatchedSetException(null,input);
				recover(mse);
				throw mse;
			}
			// T.g:37:21: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '\\_' )*
			loop3:
			while (true) {
				int alt3=2;
				int LA3_0 = input.LA(1);
				if ( ((LA3_0 >= '0' && LA3_0 <= '9')||(LA3_0 >= 'A' && LA3_0 <= 'Z')||LA3_0=='_'||(LA3_0 >= 'a' && LA3_0 <= 'z')) ) {
					alt3=1;
				}

				switch (alt3) {
				case 1 :
					// T.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9')||(input.LA(1) >= 'A' && input.LA(1) <= 'Z')||input.LA(1)=='_'||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					break loop3;
				}
			}

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "ID"

	// $ANTLR start "UC"
	public final void mUC() throws RecognitionException {
		try {
			int _type = UC;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:40:3: ( ( 'A' .. 'Z' | '\\_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '\\_' )* )
			// T.g:40:5: ( 'A' .. 'Z' | '\\_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '\\_' )*
			{
			if ( (input.LA(1) >= 'A' && input.LA(1) <= 'Z')||input.LA(1)=='_' ) {
				input.consume();
			}
			else {
				MismatchedSetException mse = new MismatchedSetException(null,input);
				recover(mse);
				throw mse;
			}
			// T.g:40:21: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '\\_' )*
			loop4:
			while (true) {
				int alt4=2;
				int LA4_0 = input.LA(1);
				if ( ((LA4_0 >= '0' && LA4_0 <= '9')||(LA4_0 >= 'A' && LA4_0 <= 'Z')||LA4_0=='_'||(LA4_0 >= 'a' && LA4_0 <= 'z')) ) {
					alt4=1;
				}

				switch (alt4) {
				case 1 :
					// T.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9')||(input.LA(1) >= 'A' && input.LA(1) <= 'Z')||input.LA(1)=='_'||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					break loop4;
				}
			}

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "UC"

	// $ANTLR start "String"
	public final void mString() throws RecognitionException {
		try {
			int _type = String;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:43:7: ( '\\'' ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' )* '\\'' )
			// T.g:43:9: '\\'' ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' )* '\\''
			{
			match('\''); 
			// T.g:43:14: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' )*
			loop5:
			while (true) {
				int alt5=2;
				int LA5_0 = input.LA(1);
				if ( ((LA5_0 >= '0' && LA5_0 <= '9')||(LA5_0 >= 'A' && LA5_0 <= 'Z')||(LA5_0 >= 'a' && LA5_0 <= 'z')) ) {
					alt5=1;
				}

				switch (alt5) {
				case 1 :
					// T.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9')||(input.LA(1) >= 'A' && input.LA(1) <= 'Z')||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					break loop5;
				}
			}

			match('\''); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "String"

	// $ANTLR start "Op"
	public final void mOp() throws RecognitionException {
		try {
			int _type = Op;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:46:3: ( '+' | '-' | '*' )
			// T.g:
			{
			if ( (input.LA(1) >= '*' && input.LA(1) <= '+')||input.LA(1)=='-' ) {
				input.consume();
			}
			else {
				MismatchedSetException mse = new MismatchedSetException(null,input);
				recover(mse);
				throw mse;
			}
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "Op"

	// $ANTLR start "WS"
	public final void mWS() throws RecognitionException {
		try {
			int _type = WS;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// T.g:49:5: ( ( ' ' | '\\t' | '\\n' | '\\r' )+ )
			// T.g:49:9: ( ' ' | '\\t' | '\\n' | '\\r' )+
			{
			// T.g:49:9: ( ' ' | '\\t' | '\\n' | '\\r' )+
			int cnt6=0;
			loop6:
			while (true) {
				int alt6=2;
				int LA6_0 = input.LA(1);
				if ( ((LA6_0 >= '\t' && LA6_0 <= '\n')||LA6_0=='\r'||LA6_0==' ') ) {
					alt6=1;
				}

				switch (alt6) {
				case 1 :
					// T.g:
					{
					if ( (input.LA(1) >= '\t' && input.LA(1) <= '\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					if ( cnt6 >= 1 ) break loop6;
					EarlyExitException eee = new EarlyExitException(6, input);
					throw eee;
				}
				cnt6++;
			}

			skip();
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "WS"

	@Override
	public void mTokens() throws RecognitionException {
		// T.g:1:8: ( T__10 | T__11 | T__12 | T__13 | Digit | ID | UC | String | Op | WS )
		int alt7=10;
		alt7 = dfa7.predict(input);
		switch (alt7) {
			case 1 :
				// T.g:1:10: T__10
				{
				mT__10(); 

				}
				break;
			case 2 :
				// T.g:1:16: T__11
				{
				mT__11(); 

				}
				break;
			case 3 :
				// T.g:1:22: T__12
				{
				mT__12(); 

				}
				break;
			case 4 :
				// T.g:1:28: T__13
				{
				mT__13(); 

				}
				break;
			case 5 :
				// T.g:1:34: Digit
				{
				mDigit(); 

				}
				break;
			case 6 :
				// T.g:1:40: ID
				{
				mID(); 

				}
				break;
			case 7 :
				// T.g:1:43: UC
				{
				mUC(); 

				}
				break;
			case 8 :
				// T.g:1:46: String
				{
				mString(); 

				}
				break;
			case 9 :
				// T.g:1:53: Op
				{
				mOp(); 

				}
				break;
			case 10 :
				// T.g:1:56: WS
				{
				mWS(); 

				}
				break;

		}
	}


	protected DFA7 dfa7 = new DFA7(this);
	static final String DFA7_eotS =
		"\5\uffff\1\13\1\uffff\1\10\5\uffff\1\10";
	static final String DFA7_eofS =
		"\16\uffff";
	static final String DFA7_minS =
		"\1\11\4\uffff\1\60\1\uffff\1\60\5\uffff\1\60";
	static final String DFA7_maxS =
		"\1\172\4\uffff\1\71\1\uffff\1\172\5\uffff\1\172";
	static final String DFA7_acceptS =
		"\1\uffff\1\1\1\2\1\3\1\4\1\uffff\1\5\1\uffff\1\6\1\7\1\10\1\11\1\12\1"+
		"\uffff";
	static final String DFA7_specialS =
		"\16\uffff}>";
	static final String[] DFA7_transitionS = {
			"\2\14\2\uffff\1\14\22\uffff\1\14\6\uffff\1\12\1\1\1\2\2\13\1\3\1\5\2"+
			"\uffff\12\6\5\uffff\1\4\1\uffff\32\11\4\uffff\1\7\1\uffff\32\10",
			"",
			"",
			"",
			"",
			"\12\6",
			"",
			"\12\15\7\uffff\32\15\4\uffff\1\15\1\uffff\32\15",
			"",
			"",
			"",
			"",
			"",
			"\12\15\7\uffff\32\15\4\uffff\1\15\1\uffff\32\15"
	};

	static final short[] DFA7_eot = DFA.unpackEncodedString(DFA7_eotS);
	static final short[] DFA7_eof = DFA.unpackEncodedString(DFA7_eofS);
	static final char[] DFA7_min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
	static final char[] DFA7_max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
	static final short[] DFA7_accept = DFA.unpackEncodedString(DFA7_acceptS);
	static final short[] DFA7_special = DFA.unpackEncodedString(DFA7_specialS);
	static final short[][] DFA7_transition;

	static {
		int numStates = DFA7_transitionS.length;
		DFA7_transition = new short[numStates][];
		for (int i=0; i<numStates; i++) {
			DFA7_transition[i] = DFA.unpackEncodedString(DFA7_transitionS[i]);
		}
	}

	protected class DFA7 extends DFA {

		public DFA7(BaseRecognizer recognizer) {
			this.recognizer = recognizer;
			this.decisionNumber = 7;
			this.eot = DFA7_eot;
			this.eof = DFA7_eof;
			this.min = DFA7_min;
			this.max = DFA7_max;
			this.accept = DFA7_accept;
			this.special = DFA7_special;
			this.transition = DFA7_transition;
		}
		@Override
		public String getDescription() {
			return "1:1: Tokens : ( T__10 | T__11 | T__12 | T__13 | Digit | ID | UC | String | Op | WS );";
		}
	}

}
